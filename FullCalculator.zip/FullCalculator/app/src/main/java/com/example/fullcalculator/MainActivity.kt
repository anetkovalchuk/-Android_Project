package com.example.fullcalculator

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fullcalculator.databinding.ActivityMainBinding
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private enum class Operation {
        ADD, SUBTRACT, MULTIPLY, DIVIDE
    }

    private lateinit var binding: ActivityMainBinding

    private var firstOperand: Double? = null
    private var currentOperation: Operation? = null
    private var isNewInput: Boolean = true
    private var isErrorState: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupDigitButtons()
        setupOperationButtons()
        setupActionButtons()
    }

    private fun setupDigitButtons() {
        val digitButtons = listOf(
            binding.btn0 to "0",
            binding.btn1 to "1",
            binding.btn2 to "2",
            binding.btn3 to "3",
            binding.btn4 to "4",
            binding.btn5 to "5",
            binding.btn6 to "6",
            binding.btn7 to "7",
            binding.btn8 to "8",
            binding.btn9 to "9"
        )

        for ((button, digit) in digitButtons) {
            button.setOnClickListener { onDigitPressed(digit) }
        }
    }

    private fun setupOperationButtons() {
        binding.btnAdd.setOnClickListener { onOperationPressed(Operation.ADD) }
        binding.btnSubtract.setOnClickListener { onOperationPressed(Operation.SUBTRACT) }
        binding.btnMultiply.setOnClickListener { onOperationPressed(Operation.MULTIPLY) }
        binding.btnDivide.setOnClickListener { onOperationPressed(Operation.DIVIDE) }
    }

    private fun setupActionButtons() {
        binding.btnDot.setOnClickListener { onDotPressed() }
        binding.btnBackspace.setOnClickListener { onBackspacePressed() }
        binding.btnEquals.setOnClickListener { onEqualsPressed() }
        binding.btnClear.setOnClickListener { clearAll() }
    }

    private fun onDigitPressed(digit: String) {
        if (isErrorState) {
            clearAll()
        }

        if (isNewInput) {
            binding.tvDisplay.text = digit
            isNewInput = false
        } else {
            val current = binding.tvDisplay.text.toString()
            binding.tvDisplay.text = if (current == "0") digit else current + digit
        }
    }

    private fun onDotPressed() {
        if (isErrorState) {
            clearAll()
        }

        if (isNewInput) {
            binding.tvDisplay.text = "0."
            isNewInput = false
            return
        }

        val current = binding.tvDisplay.text.toString()
        if (!current.contains(".")) {
            binding.tvDisplay.text = "$current."
        }
    }

    private fun onBackspacePressed() {
        if (isErrorState) {
            clearAll()
            return
        }

        if (isNewInput) return

        val current = binding.tvDisplay.text.toString()
        binding.tvDisplay.text = if (current.length > 1) {
            current.dropLast(1)
        } else {
            isNewInput = true
            "0"
        }
    }

    private fun onOperationPressed(operation: Operation) {
        if (isErrorState) return

        val displayValue = binding.tvDisplay.text.toString().toDoubleOrNull() ?: return

        if (firstOperand == null) {
            firstOperand = displayValue
        } else if (!isNewInput && currentOperation != null) {
            val intermediateResult = performCalculation(firstOperand!!, displayValue, currentOperation!!)
            if (intermediateResult == null) {
                showError()
                return
            }
            firstOperand = intermediateResult
            binding.tvDisplay.text = formatNumber(intermediateResult)
        }

        currentOperation = operation
        isNewInput = true
    }

    private fun onEqualsPressed() {
        if (isErrorState) return

        val first = firstOperand ?: return
        val op = currentOperation ?: return
        val second = binding.tvDisplay.text.toString().toDoubleOrNull() ?: return

        val result = performCalculation(first, second, op)
        if (result == null) {
            showError()
            return
        }

        binding.tvDisplay.text = formatNumber(result)
        firstOperand = null
        currentOperation = null
        isNewInput = true
    }

    private fun performCalculation(a: Double, b: Double, operation: Operation): Double? {
        return when (operation) {
            Operation.ADD -> a + b
            Operation.SUBTRACT -> a - b
            Operation.MULTIPLY -> a * b
            Operation.DIVIDE -> if (b == 0.0) null else a / b
        }
    }

    private fun showError() {
        binding.tvDisplay.text = "Помилка"
        firstOperand = null
        currentOperation = null
        isNewInput = true
        isErrorState = true
    }

    private fun clearAll() {
        firstOperand = null
        currentOperation = null
        isNewInput = true
        isErrorState = false
        binding.tvDisplay.text = "0"
    }

    private fun formatNumber(value: Double): String {
        val symbols = DecimalFormatSymbols(Locale.US)
        val formatter = DecimalFormat("0.##########", symbols)
        return formatter.format(value)
    }
}