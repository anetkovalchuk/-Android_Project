package com.example.simplecalculator

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val tag = "SimpleCalculator"

    private lateinit var etFirstNumber: EditText
    private lateinit var etSecondNumber: EditText
    private lateinit var tvResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etFirstNumber = findViewById(R.id.etFirstNumber)
        etSecondNumber = findViewById(R.id.etSecondNumber)
        tvResult = findViewById(R.id.tvResult)

        val btnAdd: Button = findViewById(R.id.btnAdd)
        val btnSubtract: Button = findViewById(R.id.btnSubtract)
        val btnMultiply: Button = findViewById(R.id.btnMultiply)
        val btnDivide: Button = findViewById(R.id.btnDivide)
        val btnClear: Button = findViewById(R.id.btnClear)

        btnAdd.setOnClickListener { calculate('+') }
        btnSubtract.setOnClickListener { calculate('-') }
        btnMultiply.setOnClickListener { calculate('*') }
        btnDivide.setOnClickListener { calculate('/') }

        btnClear.setOnClickListener {
            Log.d(tag, "Натиснуто кнопку Очистити")
            etFirstNumber.text.clear()
            etSecondNumber.text.clear()
            tvResult.text = ""
        }
    }

    private fun calculate(operator: Char) {
        val firstText = etFirstNumber.text.toString().trim()
        val secondText = etSecondNumber.text.toString().trim()

        Log.d(tag, "Операція '$operator' з числами: перше='$firstText', друге='$secondText'")

        if (firstText.isEmpty() || secondText.isEmpty()) {
            Log.w(tag, "Помилка: одне або обидва поля порожні (перше='$firstText', друге='$secondText')")
            tvResult.text = "Будь ласка, введіть обидва числа"
            return
        }

        val num1 = firstText.toDoubleOrNull()
        val num2 = secondText.toDoubleOrNull()

        if (num1 == null || num2 == null) {
            Log.w(tag, "Помилка перетворення у число: перше='$firstText', друге='$secondText'")
            tvResult.text = "Будь ласка, введіть коректні числа"
            return
        }

        if (operator == '/' && num2 == 0.0) {
            Log.w(tag, "Помилка: спроба ділення на нуль ($num1 / $num2)")
            tvResult.text = "Помилка: ділення на нуль неможливе!"
            return
        }

        val result = when (operator) {
            '+' -> num1 + num2
            '-' -> num1 - num2
            '*' -> num1 * num2
            '/' -> num1 / num2
            else -> 0.0
        }

        tvResult.text = "Результат: ${formatNumber(result)}"
    }

    private fun formatNumber(value: Double): String {
        val symbols = DecimalFormatSymbols(Locale.US)
        val formatter = DecimalFormat("0.##########", symbols)
        return formatter.format(value)
    }
}